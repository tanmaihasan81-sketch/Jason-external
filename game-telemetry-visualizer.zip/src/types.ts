export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Vector2 {
  x: number;
  y: number;
}

export interface TelemetryEntity {
  id: string;
  name: string;
  type: 'player' | 'enemy' | 'teammate' | 'bot' | 'loot';
  position: Vector3;
  velocity: Vector3;
  health: number;
  maxHealth: number;
  armor: number;
  weapon: string;
  isVisible: boolean;
  isAlive: boolean;
  teamId: number;
  stance: 'standing' | 'crouching' | 'prone';
  distanceToLocal: number;
}

export interface OverlayConfig {
  showBoxes: boolean;
  boxStyle: 'corner' | 'full' | '3d' | 'filled';
  boxColor: string;
  showLines: boolean;
  lineOrigin: 'bottom' | 'center' | 'top';
  lineColor: string;
  lineWidth: number;
  showAlerts: boolean;
  alertDistanceThreshold: number;
  showAlertSound: boolean;
  showHealthBars: boolean;
  showDistanceText: boolean;
  showNameTags: boolean;
  showSkeleton: boolean;
  showMinimap: boolean;
  minimapZoom: number;
  overlayOpacity: number;
  menuVisible: boolean;
  menuPosition: Vector2;
  themePreset: 'neon-cyan' | 'cyber-amber' | 'emerald-grid' | 'crimson-alert';
}

export interface WorldCamera {
  position: Vector3;
  rotation: Vector3; // pitch, yaw, roll in degrees
  fov: number;
  aspectRatio: number;
}
