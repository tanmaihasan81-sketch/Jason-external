import { Vector3, Vector2, WorldCamera, TelemetryEntity } from '../types';

/**
 * World-to-screen projection simulator for educational visualization.
 * Converts 3D world coordinates into 2D viewport canvas coordinates.
 */
export function projectWorldToScreen(
  worldPos: Vector3,
  camera: WorldCamera,
  screenSize: Vector2
): { screenPos: Vector2; inFront: boolean; scale: number } {
  // Translate point relative to camera position
  const dx = worldPos.x - camera.position.x;
  const dy = worldPos.y - camera.position.y;
  const dz = worldPos.z - camera.position.z;

  // Convert camera yaw and pitch to radians
  const yawRad = (camera.rotation.y * Math.PI) / 180;
  const pitchRad = (camera.rotation.x * Math.PI) / 180;

  // Apply Yaw rotation (Y-axis)
  const x1 = dx * Math.cos(yawRad) - dz * Math.sin(yawRad);
  const z1 = dx * Math.sin(yawRad) + dz * Math.cos(yawRad);
  const y1 = dy;

  // Apply Pitch rotation (X-axis)
  const y2 = y1 * Math.cos(pitchRad) - z1 * Math.sin(pitchRad);
  const z2 = y1 * Math.sin(pitchRad) + z1 * Math.cos(pitchRad);
  const x2 = x1;

  // Forward check (Z-axis in camera space)
  const inFront = z2 > 0.5;

  if (!inFront) {
    return { screenPos: { x: -1000, y: -1000 }, inFront: false, scale: 0 };
  }

  // Perspective projection calculation
  const fovRad = (camera.fov * Math.PI) / 180;
  const f = 1 / Math.tan(fovRad / 2);

  // Screen center coordinates
  const cx = screenSize.x / 2;
  const cy = screenSize.y / 2;

  // Project to screen space
  const screenX = cx + (x2 * f * (screenSize.y / screenSize.x)) / z2 * cx;
  const screenY = cy - (y2 * f) / z2 * cy;

  const scale = Math.max(0.2, Math.min(3.5, 120 / z2));

  return {
    screenPos: { x: screenX, y: screenY },
    inFront,
    scale
  };
}

/**
 * Calculates 2D bounding box dimensions from height and distance scale
 */
export function calculateBoundingBox(screenPos: Vector2, scale: number) {
  const height = 180 * (scale / 2);
  const width = height * 0.52;
  
  return {
    x: screenPos.x - width / 2,
    y: screenPos.y - height,
    width,
    height
  };
}

/**
 * Calculates Euclidean distance between two 3D points
 */
export function get3DDistance(p1: Vector3, p2: Vector3): number {
  return Math.sqrt(
    Math.pow(p1.x - p2.x, 2) +
    Math.pow(p1.y - p2.y, 2) +
    Math.pow(p1.z - p2.z, 2)
  );
}
