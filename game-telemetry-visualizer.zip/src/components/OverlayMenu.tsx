import React, { useState } from 'react';
import { OverlayConfig, TelemetryEntity } from '../types';
import {
  Sliders,
  Eye,
  Layers,
  Palette,
  Bell,
  Shield,
  X,
  Move,
  Settings,
  Terminal,
  Crosshair,
  Volume2,
  VolumeX,
  Check,
  ChevronRight,
  Maximize2
} from 'lucide-react';

interface OverlayMenuProps {
  config: OverlayConfig;
  onChangeConfig: (newConfig: Partial<OverlayConfig>) => void;
  selectedEntity: TelemetryEntity | null;
  onAddDummyEntity: () => void;
  onClearEntities: () => void;
}

export const OverlayMenu: React.FC<OverlayMenuProps> = ({
  config,
  onChangeConfig,
  selectedEntity,
  onAddDummyEntity,
  onClearEntities
}) => {
  const [activeTab, setActiveTab] = useState<'visuals' | 'alerts' | 'theme' | 'telemetry'>('visuals');
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - config.menuPosition.x,
      y: e.clientY - config.menuPosition.y
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    onChangeConfig({
      menuPosition: {
        x: Math.max(10, Math.min(window.innerWidth - 420, e.clientX - dragOffset.x)),
        y: Math.max(10, Math.min(window.innerHeight - 520, e.clientY - dragOffset.y))
      }
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  if (!config.menuVisible) {
    return (
      <button
        onClick={() => onChangeConfig({ menuVisible: true })}
        className="fixed top-4 left-4 z-50 px-3.5 py-2 bg-slate-900/90 text-cyan-400 border border-cyan-500/40 rounded-lg shadow-xl backdrop-blur-md flex items-center gap-2 hover:bg-slate-800 transition-all font-mono text-xs"
      >
        <Sliders className="w-4 h-4 text-cyan-400" />
        <span>OPEN OVERLAY MENU</span>
      </button>
    );
  }

  return (
    <div
      style={{
        left: `${config.menuPosition.x}px`,
        top: `${config.menuPosition.y}px`
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      className="fixed z-50 w-[420px] bg-slate-950/95 text-slate-100 border border-cyan-500/40 rounded-xl shadow-2xl backdrop-blur-xl flex flex-col overflow-hidden font-sans select-none"
    >
      {/* Header Bar with Drag Handle */}
      <div
        onMouseDown={handleMouseDown}
        className="px-4 py-3 bg-slate-900/80 border-b border-cyan-500/20 flex items-center justify-between cursor-move hover:bg-slate-900 transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#00f0ff]" />
          <span className="font-mono text-xs font-semibold tracking-wider text-cyan-400 uppercase">
            Tactical Telemetry Suite v3.4
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Move className="w-3.5 h-3.5 text-slate-500" />
          <button
            onClick={() => onChangeConfig({ menuVisible: false })}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900/50 text-xs font-mono">
        <button
          onClick={() => setActiveTab('visuals')}
          className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors ${
            activeTab === 'visuals'
              ? 'bg-cyan-950/50 text-cyan-400 border-b-2 border-cyan-400 font-medium'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          Visuals
        </button>
        <button
          onClick={() => setActiveTab('alerts')}
          className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors ${
            activeTab === 'alerts'
              ? 'bg-cyan-950/50 text-cyan-400 border-b-2 border-cyan-400 font-medium'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          Alerts
        </button>
        <button
          onClick={() => setActiveTab('theme')}
          className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors ${
            activeTab === 'theme'
              ? 'bg-cyan-950/50 text-cyan-400 border-b-2 border-cyan-400 font-medium'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          Style
        </button>
        <button
          onClick={() => setActiveTab('telemetry')}
          className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors ${
            activeTab === 'telemetry'
              ? 'bg-cyan-950/50 text-cyan-400 border-b-2 border-cyan-400 font-medium'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          Data
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-4 space-y-4 max-h-[380px] overflow-y-auto font-sans text-xs custom-scrollbar">
        {/* VISUAL OVERLAY TAB */}
        {activeTab === 'visuals' && (
          <div className="space-y-3.5">
            {/* Box Toggle & Styles */}
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">2D/3D Bounding Boxes</span>
                <input
                  type="checkbox"
                  checked={config.showBoxes}
                  onChange={(e) => onChangeConfig({ showBoxes: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>
              {config.showBoxes && (
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {(['corner', 'full', '3d', 'filled'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => onChangeConfig({ boxStyle: style })}
                      className={`py-1 px-2 rounded font-mono text-[10px] uppercase border transition-all ${
                        config.boxStyle === style
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-semibold'
                          : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Snaplines Configuration */}
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Direction Vector Lines</span>
                <input
                  type="checkbox"
                  checked={config.showLines}
                  onChange={(e) => onChangeConfig({ showLines: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>
              {config.showLines && (
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Line Origin</span>
                    <div className="flex gap-1">
                      {(['top', 'center', 'bottom'] as const).map((origin) => (
                        <button
                          key={origin}
                          onClick={() => onChangeConfig({ lineOrigin: origin })}
                          className={`px-2 py-0.5 rounded text-[10px] uppercase font-mono ${
                            config.lineOrigin === origin
                              ? 'bg-cyan-500/30 text-cyan-300'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {origin}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Skeletal Wireframes */}
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200">Skeletal Joint Wireframe</div>
                <div className="text-[10px] text-slate-400">Renders projected bone posture</div>
              </div>
              <input
                type="checkbox"
                checked={config.showSkeleton}
                onChange={(e) => onChangeConfig({ showSkeleton: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {/* Health & Tags */}
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Health Meter Bar</span>
                <input
                  type="checkbox"
                  checked={config.showHealthBars}
                  onChange={(e) => onChangeConfig({ showHealthBars: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Distance & Weapon Label</span>
                <input
                  type="checkbox"
                  checked={config.showDistanceText}
                  onChange={(e) => onChangeConfig({ showDistanceText: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Player Name Tag</span>
                <input
                  type="checkbox"
                  checked={config.showNameTags}
                  onChange={(e) => onChangeConfig({ showNameTags: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* ALERTS TAB */}
        {activeTab === 'alerts' && (
          <div className="space-y-3.5">
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-200">Proximity Danger Warning</div>
                  <div className="text-[10px] text-slate-400">Triggers visual ring when entity enters zone</div>
                </div>
                <input
                  type="checkbox"
                  checked={config.showAlerts}
                  onChange={(e) => onChangeConfig({ showAlerts: e.target.checked })}
                  className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                />
              </div>

              {config.showAlerts && (
                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between text-[11px] text-slate-300">
                    <span>Alert Distance Threshold:</span>
                    <span className="font-mono text-cyan-400">{config.alertDistanceThreshold}m</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="50"
                    value={config.alertDistanceThreshold}
                    onChange={(e) =>
                      onChangeConfig({ alertDistanceThreshold: Number(e.target.value) })
                    }
                    className="w-full accent-cyan-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
                  />
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200">2D Tactical Minimap</div>
                <div className="text-[10px] text-slate-400">Corner radar HUD element</div>
              </div>
              <input
                type="checkbox"
                checked={config.showMinimap}
                onChange={(e) => onChangeConfig({ showMinimap: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* THEME & COLOR TAB */}
        {activeTab === 'theme' && (
          <div className="space-y-3.5">
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2.5">
              <span className="font-medium text-slate-200">HUD Color Scheme</span>
              <div className="grid grid-cols-2 gap-2 pt-1">
                {[
                  { id: 'neon-cyan', label: 'Cyan Neon', color: '#00f0ff' },
                  { id: 'cyber-amber', label: 'Amber Cyber', color: '#f59e0b' },
                  { id: 'emerald-grid', label: 'Emerald Matrix', color: '#10b981' },
                  { id: 'crimson-alert', label: 'Crimson Alert', color: '#f43f5e' }
                ].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() =>
                      onChangeConfig({
                        themePreset: preset.id as any,
                        boxColor: preset.color,
                        lineColor: preset.color
                      })
                    }
                    className="p-2 bg-slate-800/60 hover:bg-slate-800 rounded border border-slate-700/80 flex items-center gap-2 transition-all"
                  >
                    <div
                      className="w-3.5 h-3.5 rounded-full"
                      style={{ backgroundColor: preset.color }}
                    />
                    <span className="text-slate-300 text-[11px] font-medium">{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2">
              <div className="flex justify-between text-[11px] text-slate-300">
                <span>Overlay Transparency:</span>
                <span className="font-mono text-cyan-400">{Math.round(config.overlayOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.05"
                value={config.overlayOpacity}
                onChange={(e) => onChangeConfig({ overlayOpacity: Number(e.target.value) })}
                className="w-full accent-cyan-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* TELEMETRY / DATA TAB */}
        {activeTab === 'telemetry' && (
          <div className="space-y-3.5">
            <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Simulated Telemetry Stream</span>
                <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 font-mono text-[9px] rounded border border-emerald-500/30">
                  LIVE (60 FPS)
                </span>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  onClick={onAddDummyEntity}
                  className="flex-1 py-1.5 px-2 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-500/40 rounded font-mono text-[10px] transition-colors"
                >
                  + Spawn Target Dummy
                </button>
                <button
                  onClick={onClearEntities}
                  className="py-1.5 px-2 bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 rounded font-mono text-[10px] transition-colors"
                >
                  Clear All
                </button>
              </div>
            </div>

            {selectedEntity ? (
              <div className="p-3 bg-slate-900/80 border border-cyan-500/30 rounded-lg space-y-1.5 font-mono text-[11px]">
                <div className="text-cyan-400 font-bold border-b border-slate-800 pb-1 flex justify-between">
                  <span>{selectedEntity.name}</span>
                  <span className="text-slate-400">ID: {selectedEntity.id}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-slate-300 text-[10px] pt-1">
                  <div>Type: <span className="text-white">{selectedEntity.type}</span></div>
                  <div>Health: <span className="text-emerald-400">{selectedEntity.health} HP</span></div>
                  <div>Distance: <span className="text-sky-400">{selectedEntity.distanceToLocal.toFixed(1)}m</span></div>
                  <div>Weapon: <span className="text-amber-300">{selectedEntity.weapon}</span></div>
                  <div>Stance: <span className="text-purple-300">{selectedEntity.stance}</span></div>
                  <div>
                    Pos: ({selectedEntity.position.x.toFixed(1)}, {selectedEntity.position.z.toFixed(1)})
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg text-slate-500 text-center text-[10px] italic">
                Click any target in viewport or minimap to view detailed positional telemetry data.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="px-4 py-2 bg-slate-900/90 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center font-mono">
        <span>MODE: TELEMETRY_SIMULATOR</span>
        <span className="text-cyan-500/80">LATENCY: 1.2ms</span>
      </div>
    </div>
  );
};
