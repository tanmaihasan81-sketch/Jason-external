import React, { useRef, useEffect } from 'react';
import { TelemetryEntity, OverlayConfig, WorldCamera } from '../types';
import { projectWorldToScreen, calculateBoundingBox, get3DDistance } from '../utils/projection';

interface TacticalCanvasProps {
  entities: TelemetryEntity[];
  config: OverlayConfig;
  camera: WorldCamera;
  onSelectEntity?: (entity: TelemetryEntity) => void;
  selectedEntityId?: string | null;
}

export const TacticalCanvas: React.FC<TacticalCanvasProps> = ({
  entities,
  config,
  camera,
  onSelectEntity,
  selectedEntityId
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPR rendering
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    canvas.width = width * window.devicePixelRatio;
    canvas.height = height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Render 3D Perspective Grid Background (Tactical Simulation World)
    drawTactical3DGrid(ctx, camera, { x: width, y: height });

    // Render Simulated World Entities (Dummies / Players in simulated space)
    entities.forEach((entity) => {
      if (!entity.isAlive) return;

      const { screenPos, inFront, scale } = projectWorldToScreen(
        entity.position,
        camera,
        { x: width, y: height }
      );

      if (!inFront || scale <= 0) return;

      const isSelected = entity.id === selectedEntityId;
      const box = calculateBoundingBox(screenPos, scale);

      // Draw simulated 3D target avatar representation in background canvas layer
      drawSimulatedTargetAvatar(ctx, screenPos, scale, entity, isSelected);

      // -------------------------------------------------------------
      // OVERLAY LAYER - Bounding Box, Snaplines, Distance & Health Text
      // -------------------------------------------------------------
      ctx.save();
      ctx.globalAlpha = config.overlayOpacity;

      // Color selection based on entity type or theme override
      let drawColor = config.boxColor;
      if (entity.type === 'teammate') drawColor = '#10b981'; // Green
      else if (entity.type === 'bot') drawColor = '#eab308'; // Yellow
      else if (entity.type === 'loot') drawColor = '#a855f7'; // Purple
      else if (isSelected) drawColor = '#f43f5e'; // Highlight selected

      // 1. SNAPLINES (Target direction vector)
      if (config.showLines && entity.type !== 'loot') {
        ctx.beginPath();
        ctx.strokeStyle = config.lineColor || drawColor;
        ctx.lineWidth = config.lineWidth;
        ctx.setLineDash([4, 4]);

        let startX = width / 2;
        let startY = height; // Bottom origin by default
        if (config.lineOrigin === 'center') startY = height / 2;
        if (config.lineOrigin === 'top') startY = 0;

        ctx.moveTo(startX, startY);
        ctx.lineTo(screenPos.x, screenPos.y - box.height / 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // 2. BOUNDING BOXES (Corner, Full, 3D, Filled)
      if (config.showBoxes) {
        ctx.strokeStyle = drawColor;
        ctx.lineWidth = 1.8;

        if (config.boxStyle === 'full') {
          ctx.strokeRect(box.x, box.y, box.width, box.height);
        } else if (config.boxStyle === 'filled') {
          ctx.fillStyle = `${drawColor}1a`; // 10% opacity fill
          ctx.fillRect(box.x, box.y, box.width, box.height);
          ctx.strokeRect(box.x, box.y, box.width, box.height);
        } else if (config.boxStyle === 'corner') {
          drawCornerBox(ctx, box.x, box.y, box.width, box.height, drawColor);
        } else if (config.boxStyle === '3d') {
          draw3DBox(ctx, box.x, box.y, box.width, box.height, scale, drawColor);
        }
      }

      // 3. SKELETON WIREFRAME (Simulated Joints)
      if (config.showSkeleton && entity.type !== 'loot') {
        drawSimulatedSkeleton(ctx, screenPos, scale, drawColor);
      }

      // 4. HEALTH BAR (Left side of box)
      if (config.showHealthBars && entity.type !== 'loot') {
        const barWidth = 4;
        const barX = box.x - 8;
        const barHeight = box.height;
        const healthPercent = Math.max(0, Math.min(1, entity.health / entity.maxHealth));

        // Background
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(barX, box.y, barWidth, barHeight);

        // Fill color based on health level
        let healthColor = '#22c55e'; // Green
        if (healthPercent < 0.3) healthColor = '#ef4444'; // Red
        else if (healthPercent < 0.6) healthColor = '#f59e0b'; // Amber

        ctx.fillStyle = healthColor;
        const currentBarHeight = barHeight * healthPercent;
        ctx.fillRect(
          barX,
          box.y + (barHeight - currentBarHeight),
          barWidth,
          currentBarHeight
        );
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(barX, box.y, barWidth, barHeight);
      }

      // 5. NAME TAGS & DISTANCE & WEAPON OVERLAY
      let labelY = box.y - 6;
      ctx.font = '11px "JetBrains Mono", monospace, sans-serif';
      ctx.textAlign = 'center';

      if (config.showNameTags) {
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 4;
        ctx.fillText(`${entity.name} [${entity.type.toUpperCase()}]`, screenPos.x, labelY);
        labelY -= 14;
      }

      if (config.showDistanceText) {
        const dist = entity.distanceToLocal.toFixed(1);
        ctx.fillStyle = '#38bdf8';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 4;
        ctx.fillText(`Dist: ${dist}m | Wpn: ${entity.weapon}`, screenPos.x, box.y + box.height + 14);
      }

      // 6. PROXIMITY ALERT INDICATOR
      if (config.showAlerts && entity.distanceToLocal <= config.alertDistanceThreshold && entity.type === 'enemy') {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(screenPos.x, screenPos.y - box.height / 2, 28, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText('⚠ THREAT CLOSE', screenPos.x, screenPos.y - box.height / 2 - 34);
      }

      ctx.restore();
    });

    // Draw Crosshair / Reticle in Viewport Center
    drawViewportReticle(ctx, width, height, config.boxColor);

  }, [entities, config, camera, selectedEntityId]);

  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const clickY = e.clientY - rect.top;

          // Find clicked entity in screen projection
          let clicked: TelemetryEntity | null = null;
          entities.forEach((ent) => {
            const { screenPos, inFront, scale } = projectWorldToScreen(ent.position, camera, {
              x: rect.width,
              y: rect.height
            });
            if (inFront && scale > 0) {
              const box = calculateBoundingBox(screenPos, scale);
              if (
                clickX >= box.x &&
                clickX <= box.x + box.width &&
                clickY >= box.y &&
                clickY <= box.y + box.height
              ) {
                clicked = ent;
              }
            }
          });

          if (clicked && onSelectEntity) {
            onSelectEntity(clicked);
          }
        }}
        className="w-full h-full cursor-crosshair block"
      />
    </div>
  );
};

// Helper: Draw 3D Grid floor to visualize world spatial coordinates
function drawTactical3DGrid(
  ctx: CanvasRenderingContext2D,
  camera: WorldCamera,
  screenSize: { x: number; y: number }
) {
  ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
  ctx.lineWidth = 1;

  const gridSize = 10;
  const step = 4;

  for (let x = -gridSize * step; x <= gridSize * step; x += step) {
    const p1 = projectWorldToScreen({ x, y: -1, z: 2 }, camera, screenSize);
    const p2 = projectWorldToScreen({ x, y: -1, z: 60 }, camera, screenSize);
    if (p1.inFront && p2.inFront) {
      ctx.beginPath();
      ctx.moveTo(p1.screenPos.x, p1.screenPos.y);
      ctx.lineTo(p2.screenPos.x, p2.screenPos.y);
      ctx.stroke();
    }
  }

  for (let z = 2; z <= 60; z += step) {
    const p1 = projectWorldToScreen({ x: -gridSize * step, y: -1, z }, camera, screenSize);
    const p2 = projectWorldToScreen({ x: gridSize * step, y: -1, z }, camera, screenSize);
    if (p1.inFront && p2.inFront) {
      ctx.beginPath();
      ctx.moveTo(p1.screenPos.x, p1.screenPos.y);
      ctx.lineTo(p2.screenPos.x, p2.screenPos.y);
      ctx.stroke();
    }
  }
}

// Helper: Draw Corner Bracket Bounding Box
function drawCornerBox(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string
) {
  const len = Math.min(w, h) * 0.25;
  ctx.strokeStyle = color;

  // Top Left
  ctx.beginPath();
  ctx.moveTo(x, y + len);
  ctx.lineTo(x, y);
  ctx.lineTo(x + len, y);
  ctx.stroke();

  // Top Right
  ctx.beginPath();
  ctx.moveTo(x + w - len, y);
  ctx.lineTo(x + w, y);
  ctx.lineTo(x + w, y + len);
  ctx.stroke();

  // Bottom Left
  ctx.beginPath();
  ctx.moveTo(x, y + h - len);
  ctx.lineTo(x, y + h);
  ctx.lineTo(x + len, y + h);
  ctx.stroke();

  // Bottom Right
  ctx.beginPath();
  ctx.moveTo(x + w - len, y + h);
  ctx.lineTo(x + w, y + h);
  ctx.lineTo(x + w, y + h - len);
  ctx.stroke();
}

// Helper: Draw 3D Wireframe Box projection
function draw3DBox(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  scale: number,
  color: string
) {
  const depth = w * 0.4;
  ctx.strokeRect(x, y, w, h);
  ctx.strokeRect(x + depth, y - depth, w, h);

  // Connect corners
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + depth, y - depth);

  ctx.moveTo(x + w, y);
  ctx.lineTo(x + w + depth, y - depth);

  ctx.moveTo(x, y + h);
  ctx.lineTo(x + depth, y + h - depth);

  ctx.moveTo(x + w, y + h);
  ctx.lineTo(x + w + depth, y + h - depth);
  ctx.stroke();
}

// Helper: Draw simulated skeletal joint structure
function drawSimulatedSkeleton(
  ctx: CanvasRenderingContext2D,
  screenPos: { x: number; y: number },
  scale: number,
  color: string
) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.2;

  const headY = screenPos.y - 160 * (scale / 2);
  const headRadius = 8 * (scale / 2);
  const neckY = headY + headRadius * 2;
  const spineY = neckY + 30 * (scale / 2);
  const hipY = spineY + 25 * (scale / 2);

  // Head
  ctx.beginPath();
  ctx.arc(screenPos.x, headY, Math.max(3, headRadius), 0, Math.PI * 2);
  ctx.stroke();

  // Spine
  ctx.beginPath();
  ctx.moveTo(screenPos.x, neckY);
  ctx.lineTo(screenPos.x, hipY);

  // Arms
  const armSpan = 22 * (scale / 2);
  ctx.moveTo(screenPos.x - armSpan, neckY + 10 * (scale / 2));
  ctx.lineTo(screenPos.x + armSpan, neckY + 10 * (scale / 2));

  // Legs
  const legSpan = 16 * (scale / 2);
  ctx.moveTo(screenPos.x, hipY);
  ctx.lineTo(screenPos.x - legSpan, hipY + 40 * (scale / 2));

  ctx.moveTo(screenPos.x, hipY);
  ctx.lineTo(screenPos.x + legSpan, hipY + 40 * (scale / 2));

  ctx.stroke();
}

// Helper: Draw simulated 3D character mesh avatar
function drawSimulatedTargetAvatar(
  ctx: CanvasRenderingContext2D,
  screenPos: { x: number; y: number },
  scale: number,
  entity: TelemetryEntity,
  isSelected: boolean
) {
  ctx.save();
  const height = 180 * (scale / 2);
  const width = height * 0.52;

  // Shadow on floor
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.beginPath();
  ctx.ellipse(screenPos.x, screenPos.y, width * 0.6, width * 0.2, 0, 0, Math.PI * 2);
  ctx.fill();

  if (entity.type === 'loot') {
    // Render item box
    ctx.fillStyle = '#a855f7';
    ctx.fillRect(screenPos.x - 12, screenPos.y - 20, 24, 20);
    ctx.restore();
    return;
  }

  // Body capsule / Silhouette
  ctx.fillStyle = isSelected ? 'rgba(244, 63, 94, 0.4)' : 'rgba(51, 65, 85, 0.6)';
  ctx.strokeStyle = isSelected ? '#f43f5e' : '#64748b';
  ctx.lineWidth = 1;

  ctx.beginPath();
  ctx.roundRect(
    screenPos.x - width * 0.35,
    screenPos.y - height * 0.9,
    width * 0.7,
    height * 0.85,
    8
  );
  ctx.fill();
  ctx.stroke();

  ctx.restore();
}

// Helper: Viewport Center Reticle
function drawViewportReticle(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  color: string
) {
  const cx = width / 2;
  const cy = height / 2;
  const size = 12;

  ctx.strokeStyle = color;
  ctx.lineWidth = 1.2;

  ctx.beginPath();
  ctx.moveTo(cx - size, cy);
  ctx.lineTo(cx + size, cy);
  ctx.moveTo(cx, cy - size);
  ctx.lineTo(cx, cy + size);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(cx, cy, 3, 0, Math.PI * 2);
  ctx.stroke();
}
