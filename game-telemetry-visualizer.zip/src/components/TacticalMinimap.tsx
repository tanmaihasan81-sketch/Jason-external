import React from 'react';
import { TelemetryEntity } from '../types';
import { Shield, Crosshair, Radar, Eye, Activity } from 'lucide-react';

interface TacticalMinimapProps {
  entities: TelemetryEntity[];
  zoom: number;
  onSelectEntity?: (entity: TelemetryEntity) => void;
  selectedEntityId?: string | null;
}

export const TacticalMinimap: React.FC<TacticalMinimapProps> = ({
  entities,
  zoom,
  onSelectEntity,
  selectedEntityId
}) => {
  const size = 200;
  const center = size / 2;
  const scale = 2.5 * zoom; // scale factor meter to pixel

  return (
    <div className="relative w-[200px] h-[200px] bg-slate-900/90 border border-cyan-500/30 rounded-xl overflow-hidden shadow-2xl backdrop-blur-md select-none">
      {/* Radar Sweep Arc Animation */}
      <div className="absolute inset-0 rounded-full border border-cyan-500/20 m-2 pointer-events-none" />
      <div className="absolute inset-0 rounded-full border border-cyan-500/10 m-12 pointer-events-none" />

      {/* Crosshairs */}
      <div className="absolute top-0 bottom-0 left-1/2 w-px bg-cyan-500/20" />
      <div className="absolute left-0 right-0 top-1/2 h-px bg-cyan-500/20" />

      {/* Self Indicator Center */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
        <div className="w-3 h-3 bg-cyan-400 rounded-full border-2 border-slate-950 shadow-[0_0_8px_#00f0ff]" />
        <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[8px] border-b-cyan-400 -mt-4 mx-auto" />
      </div>

      {/* Radar Blips */}
      {entities.map((ent) => {
        if (!ent.isAlive) return null;

        // Map world Z, X to 2d radar coordinates
        const mapX = center + ent.position.x * scale;
        const mapY = center - ent.position.z * scale;

        // Clip to bounds
        if (mapX < 5 || mapX > size - 5 || mapY < 5 || mapY > size - 5) return null;

        let colorBg = 'bg-cyan-500';
        if (ent.type === 'enemy') colorBg = 'bg-rose-500 shadow-[0_0_6px_#f43f5e]';
        else if (ent.type === 'teammate') colorBg = 'bg-emerald-500 shadow-[0_0_6px_#10b981]';
        else if (ent.type === 'bot') colorBg = 'bg-amber-500';
        else if (ent.type === 'loot') colorBg = 'bg-purple-500';

        const isSelected = ent.id === selectedEntityId;

        return (
          <button
            key={ent.id}
            onClick={() => onSelectEntity && onSelectEntity(ent)}
            style={{ left: `${mapX}px`, top: `${mapY}px` }}
            className={`absolute -translate-x-1/2 -translate-y-1/2 z-10 p-1 group transition-transform hover:scale-125`}
            title={`${ent.name} (${ent.type}) - ${ent.distanceToLocal.toFixed(1)}m`}
          >
            <div
              className={`w-2.5 h-2.5 rounded-full ${colorBg} ${
                isSelected ? 'ring-2 ring-white scale-125' : ''
              }`}
            />
          </button>
        );
      })}

      {/* Radar Label */}
      <div className="absolute bottom-1 left-2 text-[9px] font-mono text-cyan-400/70 tracking-widest flex items-center gap-1">
        <Radar className="w-2.5 h-2.5 animate-spin" style={{ animationDuration: '4s' }} />
        RADAR 2D
      </div>
    </div>
  );
};
