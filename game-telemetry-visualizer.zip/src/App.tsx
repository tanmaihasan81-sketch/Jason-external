import React, { useState, useEffect, useRef } from 'react';
import { TacticalCanvas } from './components/TacticalCanvas';
import { TacticalMinimap } from './components/TacticalMinimap';
import { OverlayMenu } from './components/OverlayMenu';
import { DEFAULT_CONFIG, INITIAL_ENTITIES } from './data/mockTelemetry';
import { OverlayConfig, TelemetryEntity, WorldCamera } from './types';
import {
  Shield,
  Compass,
  Eye,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Activity,
  Layers,
  Info,
  Maximize2
} from 'lucide-react';

export default function App() {
  const [config, setConfig] = useState<OverlayConfig>(DEFAULT_CONFIG);
  const [entities, setEntities] = useState<TelemetryEntity[]>(INITIAL_ENTITIES);
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>('e1');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);

  // Camera state (simulated player view)
  const [camera, setCamera] = useState<WorldCamera>({
    position: { x: 0, y: 1.6, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    fov: 75,
    aspectRatio: 16 / 9
  });

  const requestRef = useRef<number | null>(null);

  // Smooth Telemetry Movement Simulator
  useEffect(() => {
    if (!isSimulating) return;

    let angle = 0;
    const animate = () => {
      angle += 0.02;

      setEntities((prev) =>
        prev.map((ent) => {
          if (ent.type === 'loot') return ent;

          // Simple circular/patrol movement pattern for entities
          const radius = 2;
          const speedFactor = ent.type === 'enemy' ? 1 : 0.5;

          const dx = Math.sin(angle * speedFactor + parseInt(ent.id.slice(-1) || '1')) * 0.08;
          const dz = Math.cos(angle * speedFactor) * 0.05;

          const newX = ent.position.x + dx;
          const newZ = ent.position.z + dz;

          // Recalculate distance to local camera
          const dist = Math.sqrt(
            Math.pow(newX - camera.position.x, 2) +
            Math.pow(1.2 - camera.position.y, 2) +
            Math.pow(newZ - camera.position.z, 2)
          );

          return {
            ...ent,
            position: { ...ent.position, x: newX, z: newZ },
            distanceToLocal: dist
          };
        })
      );

      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isSimulating, camera.position]);

  const handleUpdateConfig = (newConfig: Partial<OverlayConfig>) => {
    setConfig((prev) => ({ ...prev, ...newConfig }));
  };

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || null;

  const handleAddDummyEntity = () => {
    const id = `e_${Date.now()}`;
    const newDummy: TelemetryEntity = {
      id,
      name: `Target_Dummy_${entities.length + 1}`,
      type: 'enemy',
      position: {
        x: (Math.random() - 0.5) * 20,
        y: 1.2,
        z: 10 + Math.random() * 25
      },
      velocity: { x: 0, y: 0, z: 0 },
      health: 100,
      maxHealth: 100,
      armor: 50,
      weapon: 'M4A1 Rifle',
      isVisible: true,
      isAlive: true,
      teamId: 9,
      stance: 'standing',
      distanceToLocal: 15
    };
    setEntities((prev) => [...prev, newDummy]);
  };

  const handleClearEntities = () => {
    setEntities([]);
    setSelectedEntityId(null);
  };

  return (
    <div className="w-screen h-screen bg-slate-950 font-sans text-slate-100 flex flex-col overflow-hidden select-none">
      {/* Top Application Navigation Bar */}
      <header className="h-12 bg-slate-900 border-b border-cyan-500/20 px-4 flex items-center justify-between z-40">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-mono text-xs font-bold text-slate-100 tracking-wider">
              TACTICAL TELEMETRY VISUALIZER
            </h1>
            <p className="text-[10px] text-slate-400">
              Educational Spatial Projection & Radar Analysis Platform
            </p>
          </div>
        </div>

        {/* Viewport Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs font-mono">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors ${
                isSimulating
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}
            >
              {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isSimulating ? 'PAUSE TELEMETRY' : 'RESUME TELEMETRY'}</span>
            </button>
            <button
              onClick={() => setEntities(INITIAL_ENTITIES)}
              className="px-2 py-1 text-slate-400 hover:text-white transition-colors"
              title="Reset Simulation Entities"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Menu Toggle button */}
          <button
            onClick={() => setConfig((prev) => ({ ...prev, menuVisible: !prev.menuVisible }))}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-2 transition-all ${
              config.menuVisible
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{config.menuVisible ? 'HIDE OVERLAY MENU' : 'CONFIG MENU'}</span>
          </button>
        </div>
      </header>

      {/* Main Viewport Workspace */}
      <main className="relative flex-1 bg-slate-950 overflow-hidden">
        {/* 3D Canvas Projection Viewport */}
        <TacticalCanvas
          entities={entities}
          config={config}
          camera={camera}
          onSelectEntity={(ent) => setSelectedEntityId(ent.id)}
          selectedEntityId={selectedEntityId}
        />

        {/* 2D Minimap Corner Overlay */}
        {config.showMinimap && (
          <div className="absolute bottom-4 right-4 z-30">
            <TacticalMinimap
              entities={entities}
              zoom={config.minimapZoom}
              onSelectEntity={(ent) => setSelectedEntityId(ent.id)}
              selectedEntityId={selectedEntityId}
            />
          </div>
        )}

        {/* Movable Configuration Menu Overlay */}
        <OverlayMenu
          config={config}
          onChangeConfig={handleUpdateConfig}
          selectedEntity={selectedEntity}
          onAddDummyEntity={handleAddDummyEntity}
          onClearEntities={handleClearEntities}
        />

        {/* Informational Educational Banner */}
        <div className="absolute bottom-4 left-4 z-20 max-w-sm p-3 bg-slate-900/80 border border-slate-800 rounded-lg backdrop-blur-md text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1.5 text-cyan-400 font-semibold font-mono">
            <Info className="w-3.5 h-3.5" />
            <span>EDUCATIONAL SPATIAL SIMULATION</span>
          </div>
          <p>
            Demonstrates 3D-to-2D screen coordinate perspective math projection matrices and custom overlay rendering in modern Canvas 2D.
          </p>
        </div>
      </main>
    </div>
  );
}
